public class FinancialForecasting {

    // Recursive method to predict future value
    public static double predictFutureValue(double currentValue, double[] growthRates, int periods) {
        // Base case: No more periods left to predict
        if (periods == 0) {
            return currentValue;
        }

        // Recursive case: Apply the growth rate and reduce the number of periods
        return predictFutureValue(currentValue * (1 + growthRates[periods - 1]), growthRates, periods - 1);
    }


    public static void main(String[] args) {
        double currentValue = 1000; // Current value
        double[] growthRates = {0.05, 0.03, 0.04, 0.02}; // Growth rates for 4 periods

        int periods = growthRates.length; // Number of periods

        double futureValue = predictFutureValue(currentValue, growthRates, periods);

        System.out.println("Future Value: " + futureValue);
    }
}
