public class InventoryManagementSystem {
    public static void main(String[] args) {
        Product[] products = {
                new Product("P1", "Laptop", "Electronics"),
                new Product("P2", "Smartphone", "Electronics"),
                new Product("P3", "Tablet", "Electronics"),
                new Product("P4", "Headphones", "Accessories"),
                new Product("P5", "Keyboard", "Accessories")
        };

        // Linear Search Test
        Product foundProduct = LinearSearch.linearSearch(products, "Tablet");
        System.out.println("Linear Search Result: " + foundProduct);

        // Binary Search Test
        foundProduct = BinarySearch.binarySearch(products, "Tablet");
        System.out.println("Binary Search Result: " + foundProduct);
    }
}
