public class InventoryManagementSystem {
    public static void main(String[] args) {
        Order[] orders = {
                new Order("O001", "Alice", 250.75),
                new Order("O002", "Bob", 150.50),
                new Order("O003", "Charlie", 450.00),
                new Order("O004", "Dave", 300.20),
                new Order("O005", "Eve", 100.10)
        };

        // Bubble Sort Test
        System.out.println("Bubble Sort:");
        BubbleSort.bubbleSort(orders);
        for (Order order : orders) {
            System.out.println(order);
        }

        // Quick Sort Test
        Order[] orders2 = {
                new Order("O001", "Alice", 250.75),
                new Order("O002", "Bob", 150.50),
                new Order("O003", "Charlie", 450.00),
                new Order("O004", "Dave", 300.20),
                new Order("O005", "Eve", 100.10)
        };

        System.out.println("\nQuick Sort:");
        QuickSort.quickSort(orders2, 0, orders2.length - 1);
        for (Order order : orders2) {
            System.out.println(order);
        }
    }
}
