public class InventoryManagementSystem {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Add products
        Product product1 = new Product("P1", "Laptop", 10, 800.0);
        Product product2 = new Product("P2", "Smartphone", 15, 500.0);

        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Display products
        System.out.println("Initial Inventory:");
        inventory.displayProducts();

        // Update product
        inventory.updateProduct("P1", 8, 750.0);
        System.out.println("\nInventory after updating product P001:");
        inventory.displayProducts();

        // Delete product
        inventory.deleteProduct("P2");
        System.out.println("\nInventory after deleting product P002:");
        inventory.displayProducts();
    }
}

