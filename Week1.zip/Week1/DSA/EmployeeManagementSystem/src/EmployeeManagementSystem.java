public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    // Add Employee
    public void addEmployee(Employee employee) {
        if (size == employees.length) {
            System.out.println("Array is full. Cannot add more employees.");
            return;
        }
        employees[size] = employee;
        size++;
    }

    // Search Employee
    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse Employees
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete Employee
    public void deleteEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[size - 1] = null;
                size--;
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);

        Employee e1 = new Employee("E001", "Alice", "Manager", 75000);
        Employee e2 = new Employee("E002", "Bob", "Developer", 55000);
        Employee e3 = new Employee("E003", "Charlie", "Designer", 50000);

        // Add employees
        ems.addEmployee(e1);
        ems.addEmployee(e2);
        ems.addEmployee(e3);

        // Traverse employees
        System.out.println("Employees:");
        ems.traverseEmployees();

        // Search employee
        System.out.println("\nSearch Employee E002:");
        System.out.println(ems.searchEmployee("E002"));

        // Delete employee
        System.out.println("\nDelete Employee E002:");
        ems.deleteEmployee("E002");

        // Traverse employees
        System.out.println("\nEmployees after deletion:");
        ems.traverseEmployees();
    }
}
