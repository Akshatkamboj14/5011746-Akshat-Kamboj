// SinglyLinkedList.java
public class SinglyLinkedList {
    private class Node {
        Task task;
        Node next;

        Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }

    private Node head;

    public SinglyLinkedList() {
        this.head = null;
    }

    // Add Task
    public void addTask(Task task) {
        Node newNode = new Node(task);
        newNode.next = head;
        head = newNode;
    }

    // Search Task
    public Task searchTask(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Traverse Tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete Task
    public void deleteTask(String taskId) {
        if (head == null) return;

        if (head.task.getTaskId().equals(taskId)) {
            head = head.next;
            return;
        }

        Node current = head;
        while (current.next != null && !current.next.task.getTaskId().equals(taskId)) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
        }
    }

    public static void main(String[] args) {
        SinglyLinkedList taskList = new SinglyLinkedList();

        Task t1 = new Task("T001", "Task 1", "Pending");
        Task t2 = new Task("T002", "Task 2", "Completed");
        Task t3 = new Task("T003", "Task 3", "In Progress");

        // Add tasks
        taskList.addTask(t1);
        taskList.addTask(t2);
        taskList.addTask(t3);

        // Traverse tasks
        System.out.println("Tasks:");
        taskList.traverseTasks();

        // Search task
        System.out.println("\nSearch Task T002:");
        System.out.println(taskList.searchTask("T002"));

        // Delete task
        System.out.println("\nDelete Task T002:");
        taskList.deleteTask("T002");

        // Traverse tasks
        System.out.println("\nTasks after deletion:");
        taskList.traverseTasks();
    }
}
