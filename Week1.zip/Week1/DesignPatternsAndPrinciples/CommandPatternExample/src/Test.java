public class Test {
    public static void main(String[] args) {
        // Creating the receiver
        Light light = new Light();

        // Creating concrete commands
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        // Creating the invoker
        RemoteControl remote = new RemoteControl();

        // Testing turning the light on
        remote.setCommand(lightOn);
        remote.pressButton();

        // Testing turning the light off
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}
