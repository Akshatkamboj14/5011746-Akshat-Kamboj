public abstract class Document {
    public abstract void save();
    public abstract void close();
    public abstract void open();
}
