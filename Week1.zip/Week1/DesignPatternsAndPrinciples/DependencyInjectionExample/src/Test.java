public class Test {
    public static void main(String[] args) {
        // Creating the repository
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Injecting the repository into the service
        CustomerService customerService = new CustomerService(customerRepository);

        // Using the service to find a customer
        String customerName = customerService.getCustomerName(2);
        System.out.println(customerName);
    }
}
