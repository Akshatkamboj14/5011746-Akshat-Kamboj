public class Test {
    public static void main(String[] args) {
        // Create the context
        PaymentContext paymentContext = new PaymentContext();

        // Set and use Credit Card payment strategy
        PaymentStrategy creditCard = new CreditCardPayment("1234-5678-9876-5432", "Stela Mark");
        paymentContext.setPaymentStrategy(creditCard);
        paymentContext.executePayment(10000.0);

        // Set and use PayPal payment strategy
        PaymentStrategy payPal = new PayPalPayment("stela.mark@example.com");
        paymentContext.setPaymentStrategy(payPal);
        paymentContext.executePayment(20000.0);
    }
}
