public class Test {
    public static void main(String[] args) {
        // Create a Computer with only required parameters
        Computer basicComputer = new Computer
                .ComputerBuilder()
                .setCPU("Intel i5")
                .setRAM("8GB")
                .build();
        System.out.println(basicComputer);

        // Create a Computer with some optional parameters
        Computer gamingComputer = new Computer.ComputerBuilder()
                .setCPU("Intel i7")
                .setRAM("16GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA GTX 1660")
                .build();
        System.out.println(gamingComputer);

        // Create a Computer with all parameters
        Computer workstationComputer = new Computer.ComputerBuilder()
                .setCPU("AMD Ryzen 9")
                .setRAM("32GB")
                .setStorage("2TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setOperatingSystem("Windows 11")
                .build();
        System.out.println(workstationComputer);
    }
}
