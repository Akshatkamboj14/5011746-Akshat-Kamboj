public class Test {
    public static void main(String[] args) {
        // Creating a Student model
        Student student = new Student("Mark Stone", 1, "A");

        // Creating a StudentView
        StudentView view = new StudentView();

        // Creating a StudentController
        StudentController controller = new StudentController(student, view);

        // Updating the view with current student details
        controller.updateView();

        // Updating student details
        controller.setStudentName("Mark Stone");
        controller.setStudentGrade("C+");

        // Updating the view again with updated student details
        controller.updateView();
    }
}
