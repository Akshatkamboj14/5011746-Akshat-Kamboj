public class Logger {

    // Private constructor to prevent instantiation
    private Logger() {
        // Initialize the logger, if needed
    }

    private static final class InstanceHolder {
        // Private static instance of Logger
        private static final Logger instance = new Logger();
    }

    // Public static method to provide access to the instance
    public static Logger getInstance() {
        return InstanceHolder.instance;
    }

    // Method to log messages
    public void log(String message) {
        System.out.println("Log message: " + message);
    }
}